package controller;

import util.DBUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = req.getSession();
                session.setAttribute("user", username);

                // Load saved cart for this user from DB
                Map<Integer, Integer> cart = new HashMap<>();

                String cartSql = "SELECT ci.product_id, ci.quantity " +
                                 "FROM cart_items ci JOIN carts c ON ci.cart_id = c.cart_id " +
                                 "WHERE c.username = ?";
                PreparedStatement cartPs = conn.prepareStatement(cartSql);
                cartPs.setString(1, username);
                ResultSet cartRs = cartPs.executeQuery();

                while (cartRs.next()) {
                    int productId = cartRs.getInt("product_id");
                    int quantity = cartRs.getInt("quantity");
                    cart.put(productId, quantity);
                }
                cartRs.close();
                cartPs.close();

                session.setAttribute("cart", cart);

                // Redirect to ProductServlet to fetch products and show home.jsp
                resp.sendRedirect("ProductServlet");
            } else {
                resp.sendRedirect("login.jsp?msg=invalid");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("login.jsp?msg=exception");
        }
    }
}
