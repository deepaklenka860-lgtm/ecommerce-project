package controller;

import util.DBUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");

        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO users (username, password, email, phone) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, email);
            ps.setString(4, phone);
            int result = ps.executeUpdate();

            if (result > 0) {
                resp.sendRedirect("login.jsp?msg=registered");
            } else {
                resp.sendRedirect("register.jsp?msg=error");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("register.jsp?msg=exception");
        }
    }
}
