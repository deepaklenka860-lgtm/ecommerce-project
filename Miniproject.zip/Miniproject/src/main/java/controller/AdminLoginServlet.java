package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

    private static final String ADMIN_ID = "admin";
    private static final String ADMIN_PASS = "admin123";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String adminId = request.getParameter("adminId");
        String password = request.getParameter("password");

        if (ADMIN_ID.equals(adminId) && ADMIN_PASS.equals(password)) {
            HttpSession session = request.getSession();
            session.setAttribute("adminUser", adminId);
            response.sendRedirect("admin/dashboard.jsp");
        } else {
            response.sendRedirect("adminLogin.jsp?msg=invalid");
        }
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect GET to admin login page
        response.sendRedirect("adminLogin.jsp");
    }

}
