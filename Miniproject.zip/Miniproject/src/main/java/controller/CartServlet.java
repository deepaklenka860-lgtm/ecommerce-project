package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import model.Product;
import util.DBUtil;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {

    // Handle adding products to cart (POST)
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    HttpSession session = request.getSession();

	    String username = (String) session.getAttribute("user");
	    if (username == null) {
	        response.sendRedirect("jsp/login.jsp");
	        return;
	    }

	    Map<Integer, Integer> cart = (Map<Integer, Integer>) session.getAttribute("cart");
	    if (cart == null) {
	        cart = new HashMap<>();
	        session.setAttribute("cart", cart);
	    }

	    String productIdStr = request.getParameter("productId");
	    int productId = Integer.parseInt(productIdStr);

	    String action = request.getParameter("action");

	    if ("remove".equals(action)) {
	        // Remove product from session cart
	        cart.remove(productId);
	    } else {
	        // Default action: add/increment product quantity
	        cart.put(productId, cart.getOrDefault(productId, 0) + 1);
	    }

	    // Sync updated session cart to database (same logic as before)
	    try (Connection conn = DBUtil.getConnection()) {
	        String cartCheckSql = "SELECT cart_id FROM carts WHERE username = ?";
	        PreparedStatement cartCheckPs = conn.prepareStatement(cartCheckSql);
	        cartCheckPs.setString(1, username);
	        ResultSet rs = cartCheckPs.executeQuery();

	        int cartId;
	        if (rs.next()) {
	            cartId = rs.getInt("cart_id");
	        } else {
	            String insertCartSql = "INSERT INTO carts (username) VALUES (?)";
	            PreparedStatement insertCartPs = conn.prepareStatement(insertCartSql, PreparedStatement.RETURN_GENERATED_KEYS);
	            insertCartPs.setString(1, username);
	            insertCartPs.executeUpdate();
	            ResultSet generatedKeys = insertCartPs.getGeneratedKeys();
	            if (generatedKeys.next()) {
	                cartId = generatedKeys.getInt(1);
	            } else {
	                throw new IOException("Failed to create cart for user: " + username);
	            }
	            insertCartPs.close();
	        }
	        rs.close();
	        cartCheckPs.close();

	        // Clear existing cart_items for this cart ID
	        String deleteItemsSql = "DELETE FROM cart_items WHERE cart_id = ?";
	        PreparedStatement deletePs = conn.prepareStatement(deleteItemsSql);
	        deletePs.setInt(1, cartId);
	        deletePs.executeUpdate();
	        deletePs.close();

	        // Insert current cart items again
	        String upsertItemSql = "INSERT INTO cart_items (cart_id, product_id, quantity) VALUES (?, ?, ?)";
	        PreparedStatement upsertItemPs = conn.prepareStatement(upsertItemSql);
	        for (Map.Entry<Integer, Integer> entry : cart.entrySet()) {
	            upsertItemPs.setInt(1, cartId);
	            upsertItemPs.setInt(2, entry.getKey());
	            upsertItemPs.setInt(3, entry.getValue());
	            upsertItemPs.addBatch();
	        }
	        upsertItemPs.executeBatch();
	        upsertItemPs.close();

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    response.sendRedirect("CartServlet");
	}



    // Display cart contents (GET)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Map<Integer, Integer> cart = null;
        if (session != null) {
            cart = (Map<Integer, Integer>) session.getAttribute("cart");
        }

        Map<Product, Integer> productsInCart = new HashMap<>();

        if (cart != null && !cart.isEmpty()) {
            try (Connection conn = DBUtil.getConnection();
                 PreparedStatement ps = conn.prepareStatement("SELECT id, name, description, price FROM products WHERE id = ?")) {

                for (Integer productId : cart.keySet()) {
                    ps.setInt(1, productId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            Product product = new Product();
                            product.setId(rs.getInt("id"));
                            product.setName(rs.getString("name"));
                            product.setDescription(rs.getString("description"));
                            product.setPrice(rs.getDouble("price"));
                            productsInCart.put(product, cart.get(productId));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        request.setAttribute("productsInCart", productsInCart);
        request.getRequestDispatcher("cart.jsp").forward(request, response);
    }
}
