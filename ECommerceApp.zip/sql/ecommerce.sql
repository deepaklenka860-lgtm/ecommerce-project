CREATE DATABASE IF NOT EXISTS ecommerce;
USE ecommerce;
-- (rest of SQL script truncated for brevity, will use full content in final output)
